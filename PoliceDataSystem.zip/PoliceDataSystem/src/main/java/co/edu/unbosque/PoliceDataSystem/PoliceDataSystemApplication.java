package co.edu.unbosque.PoliceDataSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PoliceDataSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(PoliceDataSystemApplication.class, args);
	}

}
